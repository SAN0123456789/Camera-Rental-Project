package camera_rental;

import java.util.ArrayList;

public class cam {
	private int cid;
	private String brand;
	private String model;
	private double price;
	static int id=0;
	private String status;

	
		public cam(int cid, String brand, String model, double price,String status) {
			this.cid= cid;
			this.brand = brand;
			this.model = model;
			this.price = price;
			this.status=status;
		}


		  public String toString() {
return cid + "         " + brand + "     " + model + "    " + price+ "       "+ status ;
			  }
		
		


			public int getCid() {
			return cid;
		}


		public void setCid(int cid) {
			this.cid = cid;
		}


		public String getBrand() {
			return brand;
		}


		public void setBrand(String brand) {
			this.brand = brand;
		}


		public String getModel() {
			return model;
		}


		public void setModel(String model) {
			this.model = model;
		}


		public double getPrice() {
			return price;
		}


		public void setPrice(double price) {
			this.price = price;
		}


		public static int getId() {
			return id;
		}


		public static void setId(int id) {
			cam.id = id;
		}


		public String getStatus() {
			return status;
		}


		public void setStatus(String status) {
			this.status = status;
		}


			public static void main(String[] args) {

			    cam ob[]= new cam[100];
				ArrayList<cam> li = new ArrayList<>();
				
	        	ob[0]=new cam(0,"Sony","DSLR12",200,"Available");
	        	li.add(ob[0]);
	        	ob[1]=new cam(1,"Samsung","DS123",100,"Available");
	        	li.add(ob[1]);
	        	ob[2]=new cam(2,"Canon","XPL",300,"Rented");
	        	li.add(ob[2]);
	        	ob[3]=new cam(3,"Sony","DSLR12",400,"Available");
	        	li.add(ob[3]);
	        	ob[4]=new cam(4,"Nikon","2030",200,"Available");
	        	li.add(ob[4]);

	        	System.out.println(li);
	        	for(int i = 0; i < li.size(); i++) {   
	        	    System.out.print(li.get(i));
			}
	        	     	

			}
}
