package camera_rental;

import java.util.ArrayList;
import java.util.Scanner;

class user{
	private double price=500;

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
}

public class cameras {

	
		private int cid;
		private String brand;
		private String model;
		private double price;
		static int id=0;
		private String status;

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public cameras(int cid, String brand, String model, double price,String status) {
			this.cid= cid;
			this.brand = brand;
			this.model = model;
			this.price = price;
			this.status=status;
		
		}

		  public String toString() {
			    return cid + "         " + brand + "     " + model + "    " + price+ "       "+ status ;
			  }
		
		
		public int getCid() {
			return cid;
		}


		public void setCid(int cid) {
			this.cid = cid;
		}


		public String getBrand() {
			return brand;
		}


		public void setBrand(String brand) {
			this.brand = brand;
		}


		public String getModel() {
			return model;
		}


		public void setModel(String model) {
			this.model = model;
		}


		public double getPrice() {
			return price;
		}


		public void setPrice(double price) {
			this.price = price;
		}


		
		public static void main(String[] args) {

cam ob[]= new cam[100];
ArrayList<cam> li = new ArrayList<>();
ob[0]=new cam(0,"Sony","DSLR12",200,"Available");
li.add(ob[0]);
ob[1]=new cam(1,"Samsung","DS123",100,"Available");
li.add(ob[1]);
ob[2]=new cam(2,"Canon","XPL",300,"Rented");
li.add(ob[2]);
ob[3]=new cam(3,"Sony","DSLR12",400,"Available");
li.add(ob[3]);
ob[4]=new cam(4,"Nikon","2030",200,"Available");
li.add(ob[4]);


	        cameras obj[]= new cameras[100];
	        user u = new user() ;
			ArrayList<cameras> list = new ArrayList<>();
	        Scanner s = new Scanner(System.in);
			System.out.println("WELCOME TO THE CAMERA RENTAL APP");
			ArrayList<cameras> my = new ArrayList<>();

			
	        while(true) {

		        System.out.print("Enter username:");
		        String user = s.nextLine();
		        System.out.print("Enter password:");
		        String pass = s.nextLine();

	        if(user.equals("user") && pass.equals("p"))
	        	{
	            System.out.println("Authentication Successful");
	            

	        while(true) {


				System.out.println("1. My Camera");
				System.out.println("2. Rent a Camera");
				System.out.println("3. View all Cameras");
				System.out.println("4. My WALLET");
				System.out.println("5. Exit");
				
	        	loop: 
	        	while(true) {
			System.out.println("Enter value :");
			
	        int c= s.nextInt();
	        switch (c) {
	        case 1:

		        while(true) {
					System.out.println("1. ADD");
					System.out.println("2. REMOVE");
					System.out.println("3. View My Cameras");
					System.out.println("4. Go to previous menu");
		        	
					System.out.println("Enter value");
			        int mc= s.nextInt();
			        
			        
			        switch (mc) {
			        
			        case 1:

			        	int iid=id;
			        	System.out.print("Enter Brand:\n");
			        	String b=s.next();
			        	System.out.print("Enter Model:\n");
			        	String m=s.next();
			        	System.out.print("Enter Price : ");
			        	int p=s.nextInt();
			        	String a="Available";
			        	
			        	iid=id;
			        	obj[iid]=new cameras(iid,b,m,p,a);
			        	list.add(obj[iid]);
			        	id++;
			        	System.out.println("Camera_ID | Model | Brand | Price | Status");
			        	for (int i=0 ;i<list.size();i++) {
			        		if(obj[i].getStatus()=="Available")
			        		System.out.println(obj[i]);
			        	}


			        	break;
		        		        
			        case 2:
			        	
			        	System.out.print("Enter Camera ID to remove : ");
			        	int d=s.nextInt();
			        	list.remove(obj[d]);
			        	System.out.println("Camera_ID | Model | Brand | Price | Status");
			        	for (int i=0 ;i<list.size();i++) {
			        		System.out.println(obj[i]);
			        	}
			        	break;
			        
			        case 3:
			        	System.out.println("Camera_ID | Model | Brand | Price | Status");
			        	for (int i=0 ;i<list.size();i++) {
			        		System.out.println(obj[i]);
			        	}
			        	break;
   
			        case 4:
			        	break loop;
			        }
			        
		        }
		        
	        case 2:
	        	for (int i=0 ;i<list.size();i++) {
	        		if(ob[i].getStatus()=="Available")
	        		System.out.println(ob[i]);
	        	}
	        	System.out.println("Enter camera id to Rent");
		        int r = s.nextInt();
		        if(u.getPrice()>ob[r].getPrice())
		        	{
		        	ob[r].setStatus("Rented");
		        	 u.setPrice(u.getPrice()-ob[r].getPrice());
		        	 System.out.println("Your transaction for "+ob[r].getBrand() +
		        			 ob[r].getModel()+"with rent "+ob[r].getPrice()+"has completed");
		        	}
		        
		        else {
		        	System.out.println("Insufficient balance");
		        }
		        break;
	        		
       	        	
	        case 3:
	        	System.out.println("Camera_ID | Model | Brand | Price | Status");
	        	for (int j=0 ;j<li.size();j++) {
	        		System.out.println(ob[j]);
	        	}
	        	
	          break;
	          
	        case 4:
	          System.out.println("Your current wallet balance : "+u.getPrice());
	          System.out.println("Want to add amount 1.YES 2.NO");
	          int a= s.nextInt();
	          if(a==1)       	 
	          {   System.out.println("Enter Amount : ");
	        	  double am= s.nextInt();
	        	  double pr =u.getPrice()+am;
	        	  u.setPrice(pr);
	          }
	          System.out.println("Your current wallet balance after added :  "+u.getPrice());
	          
	          break;
	          
	        case 5:
	        	System.out.println("Exit...");
	          System.exit(0);

	        

			        }
	        	}
		        }
	        	}
	      		    
	        else
	            System.out.println("Authentication Failed");

	        
     
	        }

	        }

		
}
	        
